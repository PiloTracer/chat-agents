import type { AxiosError } from "axios";

type ErrorPayload = {
  detail?: unknown;
};

export function extractErrorMessage(error: unknown, fallback: string): string {
  const axiosError = error as AxiosError<ErrorPayload> | undefined;
  const detail = axiosError?.response?.data?.detail;
  if (typeof detail === "string" && detail.trim().length > 0) {
    return detail;
  }
  const message = axiosError?.message;
  if (typeof message === "string" && message.trim().length > 0) {
    return message;
  }
  if (
    error instanceof Error &&
    typeof error.message === "string" &&
    error.message.trim().length > 0
  ) {
    return error.message;
  }
  return fallback;
}
