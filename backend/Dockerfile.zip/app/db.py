# app/db.py
from __future__ import annotations

import os
from typing import Generator

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base

# -------------------------------------------------------------------
# Connection URL
# Prefer DATABASE_URL if present; otherwise build from individual vars
# -------------------------------------------------------------------
DB_URL = os.getenv("DATABASE_URL")
if not DB_URL:
    pg_user = os.getenv("POSTGRES_USER", "raguser")
    pg_pass = os.getenv("POSTGRES_PASSWORD", "ragpass")
    pg_db   = os.getenv("POSTGRES_DB", "ragdb")
    pg_host = os.getenv("POSTGRES_HOST", "db")      # service name in docker-compose
    pg_port = os.getenv("POSTGRES_PORT", "5432")
    DB_URL = f"postgresql+psycopg://{pg_user}:{pg_pass}@{pg_host}:{pg_port}/{pg_db}"

# -------------------------------------------------------------------
# SQLAlchemy engine / session / Base
# -------------------------------------------------------------------
engine = create_engine(
    DB_URL,
    future=True,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

# ✅ Define Base here (your models import this: `from app.db import Base`)
Base = declarative_base()


def init_db() -> None:
    """
    Run one-time startup SQL bits that must happen before metadata.create_all(),
    e.g., pgvector extension.
    """
    # Create pgvector extension if you use VECTOR columns in models.py
    try:
        with engine.begin() as conn:
            conn.exec_driver_sql("CREATE EXTENSION IF NOT EXISTS vector")
    except Exception:
        # Non-fatal if the user lacks perms; tables can still be created.
        pass


# FastAPI dependency
def get_db() -> Generator:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
