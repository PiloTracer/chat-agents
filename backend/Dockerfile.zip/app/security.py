from fastapi import Header, HTTPException

class Role:
    OWNER = "owner"
    ADMIN = "admin"

def require_role(required: str):
    async def dep(x_role: str = Header(default=Role.ADMIN), x_user: str = Header(default="demo")):
        # Simple demo: owner can do anything; admin is restricted by agent ACL
        roles = {Role.OWNER, Role.ADMIN}
        if x_role not in roles:
            raise HTTPException(status_code=403, detail="Invalid role")
        return {"role": x_role, "user": x_user}
    return dep
