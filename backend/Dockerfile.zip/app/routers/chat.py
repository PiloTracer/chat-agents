from __future__ import annotations
import os
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session
import httpx

from app.db import get_db
from app.rag import search_chunks

API_KEY = os.getenv("API_KEY", "")
CHAT_BASE = os.getenv("CHAT_PROVIDER_BASE_URL", "https://api.openai.com/v1")
CHAT_MODEL = os.getenv("CHAT_MODEL", "gpt-4o-mini")

router = APIRouter(prefix="/chat", tags=["chat"])

class ChatIn(BaseModel):
    agent_slug: str
    question: str
    top_k: int = 8

def _headers() -> dict:
    if not API_KEY:
        raise HTTPException(500, "Missing API_KEY for chat provider")
    return {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

def _build_system(snippets: List[str], agent_slug: str) -> str:
    bullets = "\n".join(f"- {s.replace('\n', ' ')[:500]}" for s in snippets)
    return (
        f"You are the '{agent_slug}' domain expert. "
        f"Answer ONLY using the provided context and cite as [#].\n\nContext:\n{bullets}\n\n"
        "If the answer isn't in context, say you don't know."
    )

@router.post("/ask")
async def ask(payload: ChatIn, db: Session = Depends(get_db)):
    hits = await search_chunks(db, payload.agent_slug, payload.question, payload.top_k)
    if not hits:
        return {"answer": "I don't know.", "citations": []}

    # Prepare few best snippets
    snippets = [t for (_id, t, _src, _score) in hits][: min(8, payload.top_k)]
    citations = [{"id": _id, "source": _src, "score": round(_score, 4)} for (_id, _txt, _src, _score) in hits]

    system = _build_system(snippets, payload.agent_slug)
    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(
            f"{CHAT_BASE}/chat/completions",
            headers=_headers(),
            json={
                "model": CHAT_MODEL,
                "temperature": 0.2,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": payload.question},
                ],
            },
        )
        resp.raise_for_status()
        data = resp.json()
        content = data["choices"][0]["message"]["content"].strip()

    return {"answer": content, "citations": citations}
