from __future__ import annotations
import os
import shutil
import tempfile
from typing import List, Tuple

from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text

from app.db import get_db
from app.parsing import parse_file
from app.rag import upsert_document

router = APIRouter(prefix="/documents", tags=["documents"])

# lightweight auth stub: keep behavior simple
def require_admin():
    return {"user": os.getenv("DEV_USER", "owner"), "role": os.getenv("DEV_ROLE", "owner")}

def _normalize_ct(filename: str, content_type: str) -> str:
    ct = (content_type or "").lower()
    name = (filename or "").lower()
    if name.endswith(".pdf"): return "application/pdf"
    if name.endswith(".docx"): return "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    if name.endswith(".pptx"): return "application/vnd.openxmlformats-officedocument.presentationml.presentation"
    if name.endswith(".rtf"): return "application/rtf"
    if name.endswith(".htm") or name.endswith(".html"): return "text/html"
    return ct or "application/octet-stream"

@router.post("/upload")
async def upload(
    agent_slug: str = Form(...),
    file: UploadFile = File(...),
    ctx=Depends(require_admin),
    db: Session = Depends(get_db),
):
    if not agent_slug:
        raise HTTPException(400, "Missing agent_slug")

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = tmp.name

    filename = file.filename or "upload.bin"
    content_type = _normalize_ct(filename, file.content_type or "")

    try:
        parsed_iter = parse_file(tmp_path, content_type)
        parsed: List[Tuple[str, str]] = [(s, t) for (s, t) in parsed_iter if t and t.strip()]
        if not parsed:
            # still create a doc for visibility
            row = db.execute(
                text(
                    "INSERT INTO documents (agent_slug, filename, content_type, meta, created_at) "
                    "VALUES (:a, :f, :c, '{}'::jsonb, NOW()) RETURNING id"
                ),
                {"a": agent_slug, "f": filename[:512], "c": content_type[:128]},
            ).fetchone()
            doc_id = int(row[0])
            db.commit()
            return {"ok": True, "doc_id": doc_id, "chunks": 0, "message": "No text extracted (parser produced no content)."}

        doc_id, n_chunks = await upsert_document(
            db, agent_slug, filename, content_type, parsed
        )
        return {"ok": True, "doc_id": doc_id, "chunks": n_chunks}
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
