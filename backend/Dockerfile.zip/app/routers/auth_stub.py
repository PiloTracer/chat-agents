from fastapi import APIRouter

router = APIRouter(prefix="/auth", tags=["auth"])

@router.get("/whoami")
def whoami():
    # In real life use proper auth (NextAuth/OAuth/JWT). This is a stub.
    return {"user":"demo", "role":"owner"}
