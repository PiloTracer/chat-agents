from __future__ import annotations
import io
import os
import re
from typing import Iterable, Tuple, List
from bs4 import BeautifulSoup
from docx import Document as DocxDocument
from pptx import Presentation
import fitz  # PyMuPDF
from striprtf.striprtf import rtf_to_text

_WS_RE = re.compile(r"[ \t\r\f\v]+")
def _norm(s: str) -> str:
    s = s.replace("\u00a0", " ")
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    return _WS_RE.sub(" ", s).strip()

def _paras_from_text(txt: str) -> List[str]:
    txt = _norm(txt)
    if not txt:
        return []
    parts = [p.strip() for p in re.split(r"\n{2,}", txt)]
    return [p for p in parts if p]

def iter_html(path: str) -> Iterable[Tuple[str, str]]:
    with open(path, "rb") as f:
        raw = f.read()
    soup = BeautifulSoup(raw, "html.parser")
    for bad in soup(["script", "style", "noscript", "iframe", "header", "footer", "nav"]):
        bad.decompose()
    text = soup.get_text(separator="\n")
    for para in _paras_from_text(text):
        yield ("html", para)

def iter_docx(path: str) -> Iterable[Tuple[str, str]]:
    doc = DocxDocument(path)
    for i, p in enumerate(doc.paragraphs, start=1):
        t = _norm(p.text or "")
        if t:
            yield (f"docx:p{i}", t)

def iter_pptx(path: str) -> Iterable[Tuple[str, str]]:
    prs = Presentation(path)
    for si, slide in enumerate(prs.slides, start=1):
        lines: List[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False) and shape.text_frame:
                for para in shape.text_frame.paragraphs:
                    text = "".join(run.text or "" for run in para.runs)
                    t = _norm(text)
                    if t:
                        lines.append(t)
        if lines:
            yield (f"pptx:slide{si}", "\n".join(lines))

def iter_rtf(path: str) -> Iterable[Tuple[str, str]]:
    with open(path, "rb") as f:
        raw = f.read()
    try:
        txt = rtf_to_text(raw.decode("utf-8", errors="ignore"))
    except Exception:
        txt = rtf_to_text(raw.decode("latin-1", errors="ignore"))
    for para in _paras_from_text(txt):
        yield ("rtf", para)

def iter_pdf(path: str) -> Iterable[Tuple[str, str]]:
    doc = fitz.open(path)
    any_text = False
    for i, page in enumerate(doc, start=1):
        # Native text
        t = page.get_text("text") or ""
        for para in _paras_from_text(t):
            any_text = True
            yield (f"pdf:p{i}", para)

    if not any_text:
        # OCR fallback if Tesseract present
        try:
            import pytesseract  # type: ignore
            from PIL import Image  # type: ignore

            for i, page in enumerate(doc, start=1):
                pix = page.get_pixmap(dpi=200, alpha=False)
                img = Image.open(io.BytesIO(pix.tobytes("png")))
                t = pytesseract.image_to_string(img)
                for para in _paras_from_text(t):
                    yield (f"pdf:ocr{i}", para)
        except Exception:
            # ignore OCR errors to keep pipeline robust
            pass
    doc.close()

def parse_file(path: str, content_type: str) -> Iterable[Tuple[str, str]]:
    ct = (content_type or "").lower()
    name = os.path.basename(path).lower()

    if name.endswith((".htm", ".html")) or ct in {"text/html", "application/xhtml+xml"}:
        return iter_html(path)
    if name.endswith(".docx") or ct == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        return iter_docx(path)
    if name.endswith(".pptx") or ct == "application/vnd.openxmlformats-officedocument.presentationml.presentation":
        return iter_pptx(path)
    if name.endswith(".rtf") or ct in {"application/rtf", "text/rtf"}:
        return iter_rtf(path)
    if name.endswith(".pdf") or ct == "application/pdf":
        return iter_pdf(path)

    # generic text fallback
    try:
        with open(path, "rb") as f:
            raw = f.read()
        try:
            txt = raw.decode("utf-8")
        except UnicodeDecodeError:
            txt = raw.decode("latin-1", errors="ignore")
        for para in _paras_from_text(txt):
            yield ("text", para)
    except Exception:
        return []
