# app/main.py
from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Import DB primitives and run-time init
from app.db import engine, Base, init_db

# Import your models so their metadata is registered on Base
# (do not remove; importing ensures tables are known to SQLAlchemy)
import app.models  # noqa: F401

# Import your existing routers
from app.routers import documents, chat  # add other routers if you have them


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Ensure pgvector (if available) and THEN create tables
    init_db()
    # Create all tables if they don't exist
    with engine.begin() as conn:
        Base.metadata.create_all(bind=conn, checkfirst=True)
    yield
    # (optional) shutdown hooks here


app = FastAPI(
    title="Multi-Agent RAG",
    version="0.1.0",
    lifespan=lifespan,
)

# CORS
allowed = os.getenv("ALLOWED_ORIGINS", "*")
origins = [o.strip() for o in allowed.split(",")] if allowed != "*" else ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(documents.router)
app.include_router(chat.router)

@app.get("/health")
def health():
    return {"ok": True}
