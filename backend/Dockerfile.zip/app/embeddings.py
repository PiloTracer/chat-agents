from __future__ import annotations
import os
from typing import List, Sequence
import httpx

API_KEY = os.getenv("API_KEY", "")
BASE_URL = os.getenv("EMBEDDING_PROVIDER_BASE_URL", "https://api.openai.com/v1")
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")
BATCH_SIZE = int(os.getenv("EMBEDDING_BATCH_SIZE", "64"))

def _headers() -> dict:
    if not API_KEY:
        raise RuntimeError("API_KEY is missing.")
    return {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

async def _call(client: httpx.AsyncClient, inputs: Sequence[str]) -> List[List[float]]:
    resp = await client.post(
        f"{BASE_URL}/embeddings",
        headers=_headers(),
        json={"model": EMBEDDING_MODEL, "input": list(inputs)},
        timeout=120,
    )
    resp.raise_for_status()
    j = resp.json()
    return [row["embedding"] for row in j["data"]]

async def embed_texts(texts: Sequence[str]) -> List[List[float]]:
    if not texts:
        return []
    out: List[List[float]] = []
    async with httpx.AsyncClient(timeout=120) as client:
        i = 0
        while i < len(texts):
            chunk = texts[i : i + BATCH_SIZE]
            vecs = await _call(client, chunk)
            out.extend(vecs)
            i += BATCH_SIZE
    return out
