from __future__ import annotations
from typing import Iterable, List, Tuple, Sequence
from math import sqrt
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.embeddings import embed_texts

def chunk_text(items: Sequence[Tuple[str, str]], max_chars: int = 1400, overlap: int = 150) -> List[Tuple[str, str]]:
    """
    items: list of (source_ref, paragraph)
    returns: list of (source_ref, chunk_text)
    """
    chunks: List[Tuple[str, str]] = []
    buf: List[str] = []
    src = None
    size = 0

    for sref, para in items:
        if not para:
            continue
        if src is None:
            src = sref
        if size + len(para) + 1 <= max_chars:
            buf.append(para)
            size += len(para) + 1
        else:
            if buf:
                ch = "\n".join(buf)
                chunks.append((src, ch))
                tail = ch[-overlap:] if overlap > 0 else ""
                buf = ([tail] if tail else []) + [para]
                size = len("\n".join(buf))
                src = sref
            else:
                # huge single paragraph
                for i in range(0, len(para), max_chars):
                    chunks.append((sref, para[i:i+max_chars]))
                buf, size, src = [], 0, None
    if buf:
        chunks.append((src or "src", "\n".join(buf)))
    return chunks

async def upsert_document(
    db: Session,
    agent_slug: str,
    filename: str,
    content_type: str,
    parsed_items: Iterable[Tuple[str, str]],
) -> Tuple[int, int]:
    """
    Insert one row into documents, then chunk+embed+insert into chunks.
    Returns (doc_id, n_chunks).
    """
    # include created_at to avoid NOT NULL issues on some setups
    row = db.execute(
        text(
            "INSERT INTO documents (agent_slug, filename, content_type, meta, created_at) "
            "VALUES (:a, :f, :c, '{}'::jsonb, NOW()) RETURNING id"
        ),
        {"a": agent_slug, "f": filename[:512], "c": content_type[:128]},
    ).fetchone()
    doc_id = int(row[0])

    items = list(parsed_items)
    chunks = chunk_text(items)
    if not chunks:
        db.commit()
        return doc_id, 0

    texts = [t for _, t in chunks]
    vecs = await embed_texts(texts)

    params = []
    for (sref, txt), emb in zip(chunks, vecs):
        params.append(
            {"a": agent_slug[:64], "d": doc_id, "t": txt, "s": (sref or "src")[:512], "e": emb}
        )

    db.execute(
        text(
            "INSERT INTO chunks (agent_slug, doc_id, text, source_ref, embedding) "
            "VALUES (:a, :d, :t, :s, :e)"
        ),
        params,
    )
    db.commit()
    return doc_id, len(params)

def _cosine(a: Sequence[float], b: Sequence[float]) -> float:
    num = sum(x*y for x, y in zip(a, b))
    da = sqrt(sum(x*x for x in a)) or 1.0
    db = sqrt(sum(y*y for y in b)) or 1.0
    return num / (da * db)

async def search_chunks(db: Session, agent_slug: str, query: str, top_k: int = 8) -> List[Tuple[int, str, str, float]]:
    """
    Return [(id, text, source_ref, score)] for top_k chunks.
    We compute cosine in Python (no pgvector operator usage).
    """
    qvec = (await embed_texts([query]))[0]

    # fetch candidate pool; tune LIMIT for your data size
    rows = db.execute(
        text(
            "SELECT id, text, source_ref, embedding FROM chunks "
            "WHERE agent_slug = :a "
            "ORDER BY id DESC LIMIT 2000"
        ),
        {"a": agent_slug},
    ).fetchall()

    scored: List[Tuple[int, str, str, float]] = []
    for rid, rtext, sref, emb in rows:
        scored.append((rid, rtext, sref, _cosine(qvec, emb)))
    scored.sort(key=lambda r: r[3], reverse=True)
    return scored[: max(1, top_k)]
