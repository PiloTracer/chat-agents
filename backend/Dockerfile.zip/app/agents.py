# app/agents.py
from __future__ import annotations
import enum
import httpx
from app.config import settings

class Role(str, enum.Enum):
    OWNER = "owner"
    ADMIN = "admin"
    USER = "user"  # used by chat dependency

def require_role(role: Role):
    # Minimal stub that you can replace with your real ACL.
    # It keeps your existing flow unblocked.
    def _dep():
        return {"user": "localuser", "role": Role.OWNER}
    return _dep

AGENTS = {
    "local-regs": "Expert in Costa Rica/local regulations.",
    "intl-regs": "Expert in international regulations, treaties, standards.",
    "logistics": "Expert in import/export logistics & procedures.",
    "internal": "Expert in your company's internal policies & SOPs."
}

SYSTEM_ROUTER = """You are a router. Given a user question, choose ONE agent slug:
- local-regs
- intl-regs
- logistics
- internal
Reply with ONLY the slug."""

async def route_question(question: str) -> str:
    headers = {"Authorization": f"Bearer {settings.API_KEY}"}
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post(
            f"{settings.CHAT_PROVIDER_BASE_URL.rstrip('/')}/chat/completions",
            json={
                "model": settings.CHAT_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_ROUTER},
                    {"role": "user", "content": question},
                ],
                "temperature": 0,
            },
            headers=headers,
        )
        r.raise_for_status()
        slug = r.json()["choices"][0]["message"]["content"].strip()
        return slug if slug in AGENTS else "internal"

def build_system_prompt(agent_slug: str, snippets: list[str]) -> str:
    role = AGENTS.get(agent_slug, "Expert assistant")
    context = "\n\n".join(f"• {s}" for s in snippets)
    return f"""{role}
Answer using ONLY the provided context and cite sources as [#].
Context:
{context}
If unsure, say you don't know."""
