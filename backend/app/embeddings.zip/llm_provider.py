# app/llm_provider.py
from __future__ import annotations
from typing import Dict, List, Optional
import logging
import httpx

from app.config import settings

logger = logging.getLogger(__name__)

class LLMProvider:
    """Unified chat completion client for OpenAI and DeepSeek."""
    def __init__(self) -> None:
        self.providers = {
            "openai": {
                "base_url": settings.CHAT_PROVIDER_BASE_URL.rstrip("/") if "openai" in settings.CHAT_MODEL.lower() or settings.CHAT_PROVIDER_BASE_URL else (getattr(settings, "OPENAI_BASE_URL", "https://api.openai.com/v1")).rstrip("/"),
                "api_key": getattr(settings, "OPENAI_API_KEY", settings.API_KEY),
                "default_model": getattr(settings, "CHAT_MODEL", "gpt-4.1"),
            },
            "deepseek": {
                "base_url": getattr(settings, "DEEPSEEK_API_BASE", "https://api.deepseek.com/v1").rstrip("/"),
                "api_key": getattr(settings, "DEEPSEEK_API_KEY", ""),
                "default_model": getattr(settings, "DEEPSEEK_CHAT_MODEL", "deepseek-chat"),
            },
        }

    async def chat_completion(
        self,
        messages: List[Dict[str, str]],
        provider: Optional[str] = None,
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        retries: int = 2,
    ) -> Dict[str, str]:
        """Return { 'content': str, 'provider': str }"""
        chosen = self._normalize_provider(provider) or "openai"
        order = [chosen]
        if retries > 0:
            order += [p for p in ("openai","deepseek") if p != chosen]

        last_err: Optional[Exception] = None
        for prov in order:
            try:
                return {
                    "content": await self._call_provider(
                        prov, messages, model=model, temperature=temperature, max_tokens=max_tokens
                    ),
                    "provider": prov,
                }
            except Exception as e:
                last_err = e
                logger.warning("LLM call failed on %s: %s", prov, e)
                continue
        assert last_err is not None
        raise last_err

    def _normalize_provider(self, p: Optional[str]) -> Optional[str]:
        if not p:
            return None
        pl = p.strip().lower()
        if pl in {"gpt","openai"}:
            return "openai"
        if pl in {"deepseek","ds"}:
            return "deepseek"
        return None

    async def _call_provider(
        self,
        prov: str,
        messages: List[Dict[str, str]],
        model: Optional[str],
        temperature: Optional[float],
        max_tokens: Optional[int],
    ) -> str:
        if prov not in self.providers:
            raise RuntimeError(f"Unknown provider '{prov}'")

        cfg = self.providers[prov]
        base_url = cfg["base_url"]
        api_key = cfg["api_key"]
        use_model = model or cfg["default_model"]
        if not api_key:
            raise RuntimeError(f"Missing API key for provider '{prov}'")

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        }
        payload = {
            "model": use_model,
            "messages": messages,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        async with httpx.AsyncClient(timeout=settings.HTTP_TIMEOUT_SECONDS) as client:
            resp = await client.post(f"{base_url}/chat/completions", headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"]

llm_provider = LLMProvider()
